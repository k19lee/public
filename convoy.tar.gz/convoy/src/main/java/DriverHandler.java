import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Transaction;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class DriverHandler extends AbstractRequestHandler {
    public DriverHandler(JedisPool jedis) {
	this.pool = jedis;
    }

    // Incrementing id for each new driver
    public static final String DRIVER_ID = "g_driver_id";
    
    protected JSONObject childHandle(JSONObject in, Jedis jedis) throws InterruptedException {
	JSONObject res = new JSONObject();

	int capacity = in.getInt("capacity");
	// Prevent race conditions where two clients try to create drivers at the same time with WATCH
	// One will pass, one will fail. Retrying should solve the problem.
	// https://redis.io/topics/transactions
	jedis.watch(DriverHandler.DRIVER_ID);

	// Grab the next driver id
	String driverId = jedis.get(DriverHandler.DRIVER_ID);
	if ( driverId == null ) {
	    driverId = "0";
	}
	
	// Add a new driver, and increment the driver id in a transaction
	Transaction t = jedis.multi();
	t.set(DriverHandler.DRIVER_ID, String.valueOf(Long.parseLong(driverId)+1));

	Map<String, String> driverObj = new HashMap<>();
	driverObj.put("id", driverId);
	driverObj.put("capacity", String.valueOf(capacity));

	t.hmset("driver:"+driverId, driverObj);

	// Drivers are in two indexes. Number of offers, and capacity. Add those
	t.zadd("driver_num_offers", 0, driverId);
	t.zadd("driver_capacities", capacity, driverId);

	// If the transaction fails due to concurrent modification, then return an error
	List<Object> execResult = t.exec();
	if ( execResult == null || execResult.isEmpty() ) {
	    throw new InterruptedException();
	}

	// Return the driver id
	res.put("id", "driver:"+driverId);
	return res;
    }
}
