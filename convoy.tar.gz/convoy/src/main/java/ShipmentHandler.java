import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Transaction;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

public class ShipmentHandler extends AbstractRequestHandler {
    public ShipmentHandler(JedisPool jedis) {
	this.pool = jedis;
    }

    public static final String SHIPMENT_ID = "g_shipment_id";
    
    protected JSONObject childHandle(JSONObject in, Jedis jedis) throws InterruptedException {
	JSONObject res = new JSONObject();

	int capacity = in.getInt("capacity");

	// Query for drivers with capacity >= this
	Set<String> query = jedis.zrangeByScore("driver_capacities", capacity, Double.MAX_VALUE);
	// Put the results into a temporary sorted set
	String tempSetName = "temp_set_" + String.valueOf(System.currentTimeMillis());
	for ( String driverId : query ) {
	    jedis.zadd(tempSetName, 0, driverId);
	}
	String tempSetName2 = "temp_results_" + String.valueOf(System.currentTimeMillis());
	// Intersect the results with the num_offers set to sort them by num_offers
	jedis.zinterstore(tempSetName2, tempSetName, "driver_num_offers");
	// Get the first 10 results
	Set<String> drivers = jedis.zrange(tempSetName2, 0, 9);

	// We're not going to use these again, so delete them
	jedis.del(tempSetName);
	jedis.del(tempSetName2);
	
	// Start creating the offers.
	List<Map<String, String>> offers = new LinkedList<>();
	for ( String driver : drivers ) {
	    Map<String, String> offerObj = new HashMap<>();
	    offerObj.put("status", OfferStatus.ACTIVE.toString());
	    offerObj.put("driver_id", driver);
	    offers.add(offerObj);
	}

	// Lock on shipment id, to prevent simultaneous shipment creation
	jedis.watch(ShipmentHandler.SHIPMENT_ID);
	String shipmentId = jedis.get(ShipmentHandler.SHIPMENT_ID);
	if ( shipmentId == null ) {
	    shipmentId = "0";
	}
	Transaction t = jedis.multi();
	t.set(ShipmentHandler.SHIPMENT_ID, String.valueOf(Long.parseLong(shipmentId)+1));

	for ( Map<String, String> offer : offers ) {
	    // Create offers inside the transaction, now that we have the shipment id
	    String offerId = offer.get("driver_id") + ":" + shipmentId;
	    offer.put("id", offerId);
	    offer.put("shipment_id", shipmentId);
	    t.hmset("offer:" + offerId, offer);
	    // Add one to the driver and shipment lists.
	    t.rpush("driver_offers:" + offer.get("driver_id"), offerId);
	    t.rpush("shipment_offers:" + shipmentId, offerId);
	    // increment the driver offer count
	    t.zincrby("driver_num_offers", 1, offer.get("driver_id"));
	}

	// Create the shipment
	Map<String, String> shipmentObj = new HashMap<>();
	shipmentObj.put("id", shipmentId);
	shipmentObj.put("capacity", String.valueOf(capacity));
	t.hmset("shipment:"+shipmentId, shipmentObj);
	List<Object> execResult = t.exec();
	if ( execResult == null || execResult.isEmpty() ) {
	    throw new InterruptedException();
	}

	// Return the shipment id and offers
	res.put("id", "shipment:"+shipmentId);
	res.put("offers", offers);
	return res;
    }
}
