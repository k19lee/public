import org.json.JSONObject;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import static spark.Spark.get;
import static spark.Spark.post;
import static spark.Spark.put;
import spark.Request;

public class Main {
    public static void main(String [] args) {
	JedisPool pool = new JedisPool(new JedisPoolConfig(), "localhost", 6379);

	DriverHandler dh = new DriverHandler(pool);
	ShipmentHandler sh = new ShipmentHandler(pool);
	GetShipmentHandler gsh = new GetShipmentHandler(pool);
	GetDriverHandler gdh = new GetDriverHandler(pool);
	PutOfferHandler poh = new PutOfferHandler(pool);
	
	post("/driver", (req, res) -> dh.handleRequest(req, res));
	post("/shipment", (req, res) -> sh.handleRequest(req, res));
	get("/shipment/:id", (req, res) -> gsh.handleRequest(req, res));
	get("/driver/:id", (req, res) -> gdh.handleRequest(req, res));
	put("/offer/:id", (req, res) -> poh.handleRequest(req, res));
    }
}
