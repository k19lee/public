import java.util.Map;
import org.json.JSONObject;
import org.json.JSONException;
import org.apache.log4j.Logger;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Jedis;
import spark.Request;
import spark.Response;

/**
 * All request handlers inherit from this class.
 * It parses the input, then delegates to the child class. Then it parses the output
 */

public abstract class AbstractRequestHandler {
    protected Logger log = Logger.getLogger(this.getClass());
    protected JedisPool pool = null;

    public String handleRequest(Request req, Response resp) {
	try {
	    // Merge the url params and the request body params into a single JSONObject
	    Map<String, String> reqParams = req.params();
	    JSONObject jo = new JSONObject();
	    if ( req.body().length() > 0 ) {
		jo = new JSONObject(req.body());
	    }
	    
	    for ( Map.Entry<String, String> ent : reqParams.entrySet() ) {
		String key = ent.getKey().substring(1);
		jo.put(key, ent.getValue());
	    }

	    // Grab a resource from the connection pool
	    try (Jedis jedis = pool.getResource()) {
		JSONObject result = childHandle(jo, jedis);
		return result.toString(4);
	    }
	} catch ( JSONException e ) {
	    log.error(e);
	    resp.status(500);
	    return "{'error': 'error parsing input'}";
	} catch ( InterruptedException e ) {
	    return "{'error': 'concurrency error. try again'}";
	} catch ( Exception e ) {
	    e.printStackTrace();
	    log.error(e);
	    resp.status(500);
	    return "{'error': 'internal error'}";
	}
    }

    protected abstract JSONObject childHandle(JSONObject o, Jedis jedis) throws InterruptedException;
}
