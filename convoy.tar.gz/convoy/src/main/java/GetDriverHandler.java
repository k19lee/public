import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;

public class GetDriverHandler extends AbstractRequestHandler {
    public GetDriverHandler(JedisPool jedis) {
	this.pool = jedis;
    }

    protected JSONObject childHandle(JSONObject in, Jedis jedis) {
	long driverId = in.getLong("id");

	// Look up all the offers for the specified driver
	List<String> offers = jedis.lrange("driver_offers:" + String.valueOf(driverId), 0, -1);

	List<Map<String, String>> result = new LinkedList<>();
	for ( String o : offers ) {
	    // For each offer id, look up the offer object.
	    // If it has an active status, then add it to the result
	    Map<String, String> off = jedis.hgetAll("offer:" + o);
	    if ( off.get("status").equals(OfferStatus.ACCEPTED.toString()) ||
		 off.get("status").equals(OfferStatus.ACTIVE.toString()) ) {
		result.add(off);
	    }
	}

	JSONObject res = new JSONObject();
	res.put("offers", result);
	return res;
    }
}
