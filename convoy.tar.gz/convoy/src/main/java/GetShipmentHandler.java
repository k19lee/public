import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;

public class GetShipmentHandler extends AbstractRequestHandler {
    public GetShipmentHandler(JedisPool jedis) {
	this.pool = jedis;
    }

    protected JSONObject childHandle(JSONObject in, Jedis jedis) {
	long shipmentId = in.getLong("id");

	// Get all the offer ids for a shipment
	List<String> offers = jedis.lrange("shipment_offers:" + String.valueOf(shipmentId), 0, -1);

	boolean foundAccepted = false;
	List<Map<String, String>> result = new LinkedList<>();
	for ( String o : offers ) {
	    // Get the offer object for each offer id
	    Map<String, String> off = jedis.hgetAll("offer:" + o);

	    // If we find one that's accepted, then that should be the only one we return.
	    // Otherwise, return all the active offers
	    if ( off.get("status").equals(OfferStatus.ACCEPTED.toString()) ) {
		result.clear();
		result.add(off);
		foundAccepted = true;
		break;
	    } else if ( off.get("status").equals(OfferStatus.ACTIVE.toString()) ) {
		result.add(off);
	    }
	}

	JSONObject res = new JSONObject();
	res.put("accepted", foundAccepted);
	res.put("offers", result);
	return res;
    }
}
