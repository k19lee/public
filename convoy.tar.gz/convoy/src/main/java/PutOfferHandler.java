import org.json.JSONObject;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Transaction;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;

public class PutOfferHandler extends AbstractRequestHandler {
    public PutOfferHandler(JedisPool jedis) {
	this.pool = jedis;
    }

    protected JSONObject childHandle(JSONObject in, Jedis jedis) throws InterruptedException{
	String offerId = in.getString("id");
	String status = in.getString("status");

	Map<String, String> off = jedis.hgetAll("offer:" + offerId);

	if ( off != null ) {
	    String shipmentId = off.get("shipment_id");

	    // Make a transaction lock on the shipment id, because if we see multiple offer operations
	    // belonging to the same shipment, we shouldn't handle them at the same time
	    jedis.watch("offer_shipment_lock:" + shipmentId);
	    String shipmentLock = jedis.get("offer_shipment_lock:" + shipmentId);
	    if ( shipmentLock == null ) {
		shipmentLock = "0";
	    }
	    List<String> offers = jedis.lrange("shipment_offers:" + shipmentId, 0, -1);

	    // If the offer isn't active (possibly due to another offer being accepted), then
	    // we can't change the status
	    String curStatus = jedis.hget("offer:" + offerId, "status");
	    if ( !curStatus.equals(OfferStatus.ACTIVE.toString()) ) {
		return new JSONObject();
	    }
		
	    Transaction t = jedis.multi();
	    t.set("offer_shipment_lock:" + shipmentId, String.valueOf(Long.parseLong(shipmentLock)+1));
	    if ( status.equals("PASS") ) {
		t.hset("offer:" + offerId, "status", OfferStatus.REJECTED.toString());

		// Remove the offer from the shipment offer list
		String driverId = offerId.substring(0, offerId.indexOf(":"));
		t.lrem("shipment_offers:" + shipmentId, 0, offerId);

	    } else if (status.equals("ACCEPT") ) {			   
		t.hset("offer:" + offerId, "status", OfferStatus.ACCEPTED.toString());

		// After accepting an offer, cancel all other offers for the same shipment
		for ( String o : offers ) {
		    if ( !o.equals(offerId) ) {
			t.hset("offer:" + o, "status", OfferStatus.CANCELLED.toString());

			// Remove the offer from the shipment offer list
			String driverId = o.substring(0, o.indexOf(":"));
			t.lrem("shipment_offers:" + shipmentId, 0, o);
		    }
		}
	    } else {
		throw new RuntimeException("Invalid status: " + status);
	    }

	    List<Object> execResult = t.exec();
	    if ( execResult == null || execResult.isEmpty() ) {
		throw new InterruptedException();
	    }
	}

	JSONObject res = new JSONObject();
	return res;
    }
}
