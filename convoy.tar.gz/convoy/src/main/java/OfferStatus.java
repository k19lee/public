public enum OfferStatus {
    ACTIVE,
    ACCEPTED,
    REJECTED,
    CANCELLED
}

