import org.junit.*;
import static org.junit.Assert.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;
import java.util.*;
import redis.clients.jedis.Jedis;

public class MainTest {
    private static final String BASE_URL = "http://localhost:4567";

    // Before every test, wipe out the database
    @Before
    public void clearDb() {
	Jedis j = new Jedis("localhost", 6379);
	j.flushAll();
    }
    
    @Test
    public void testBasic() throws Exception {
	sendPost("/driver", "{'capacity':50}");
	sendPost("/driver", "{'capacity':100}");
	// This shipment should be offered to both drivers
	sendPost("/shipment", "{'capacity':50}");

	// This driver should have one offer, which should link to shipment 0
	JSONObject d0 = sendGet("/driver/0");
	assertEquals(1, d0.getJSONArray("offers").length());
	assertEquals("0:0", d0.getJSONArray("offers").getJSONObject(0).getString("id"));

	// This shipment should have two offers, which should link to drivers 0 and 1
	JSONObject s0 = sendGet("/shipment/0");
	assertEquals(2, s0.getJSONArray("offers").length());
	assertEquals(false, s0.getBoolean("accepted"));
	assertEquals("0:0", s0.getJSONArray("offers").getJSONObject(0).getString("id"));
	assertEquals("1:0", s0.getJSONArray("offers").getJSONObject(1).getString("id"));

	// Driver 0 accepts shipment 0
	sendPut("/offer/0:0", "{'status': 'ACCEPT'}");

	// Driver 0 should still have the one offer, even though it's been accepted
	d0 = sendGet("/driver/0");
	assertEquals(1, d0.getJSONArray("offers").length());
	assertEquals("0:0", d0.getJSONArray("offers").getJSONObject(0).getString("id"));
	assertEquals("ACCEPTED", d0.getJSONArray("offers").getJSONObject(0).getString("status"));

	// Driver 1 should have no offers
	JSONObject d1 = sendGet("/driver/1");
	assertEquals(0, d1.getJSONArray("offers").length());

	// Shipment 0 should just have the one accepted offer
	s0 = sendGet("/shipment/0");
	assertEquals(1, s0.getJSONArray("offers").length());
	assertEquals(true, s0.getBoolean("accepted"));
	assertEquals("0:0", s0.getJSONArray("offers").getJSONObject(0).getString("id"));
    }

    @Test
    public void testSorting() throws Exception {
     	sendPost("/driver", "{'capacity':50}");
     	sendPost("/driver", "{'capacity':100}");
     	// This shipment should be offered to both drivers, 0, 1
     	JSONObject s0 = sendPost("/shipment", "{'capacity':50}");
     	assertEquals(2, s0.getJSONArray("offers").length());
     	assertEquals("0:0", s0.getJSONArray("offers").getJSONObject(0).getString("id"));
     	assertEquals("1:0", s0.getJSONArray("offers").getJSONObject(1).getString("id"));

     	sendPost("/driver", "{'capacity':25}");
     	sendPost("/driver", "{'capacity':150}");
     	// This shipment should be offered to three drivers, 0, 1, and 3, with 3 in front
     	JSONObject s1 = sendPost("/shipment", "{'capacity':50}");
     	assertEquals(3, s1.getJSONArray("offers").length());
     	assertEquals("3:1", s1.getJSONArray("offers").getJSONObject(0).getString("id"));
     	assertEquals("0:1", s1.getJSONArray("offers").getJSONObject(1).getString("id"));
     	assertEquals("1:1", s1.getJSONArray("offers").getJSONObject(2).getString("id"));

     	sendPost("/driver", "{'capacity':200}");
     	// This shipment should be offered to drivers 0, 1, 3, and 4.
     	// Order should be 4,3,0,1
     	JSONObject s2 = sendPost("/shipment", "{'capacity':30}");
     	assertEquals(4, s2.getJSONArray("offers").length());
     	assertEquals("4:2", s2.getJSONArray("offers").getJSONObject(0).getString("id"));
     	assertEquals("3:2", s2.getJSONArray("offers").getJSONObject(1).getString("id"));
     	assertEquals("0:2", s2.getJSONArray("offers").getJSONObject(2).getString("id"));
     	assertEquals("1:2", s2.getJSONArray("offers").getJSONObject(3).getString("id"));

     	// This shipment should be offered to all drivers.
     	// Order should be 2, 4, 3, 0, 1
     	JSONObject s3 = sendPost("/shipment", "{'capacity':5}");
     	assertEquals(5, s3.getJSONArray("offers").length());
     	assertEquals("2:3", s3.getJSONArray("offers").getJSONObject(0).getString("id"));
     	assertEquals("4:3", s3.getJSONArray("offers").getJSONObject(1).getString("id"));
     	assertEquals("3:3", s3.getJSONArray("offers").getJSONObject(2).getString("id"));
     	assertEquals("0:3", s3.getJSONArray("offers").getJSONObject(3).getString("id"));
     	assertEquals("1:3", s3.getJSONArray("offers").getJSONObject(4).getString("id"));

     	// Add a bunch more drivers
     	sendPost("/driver", "{'capacity':200}");
     	sendPost("/driver", "{'capacity':250}");
     	sendPost("/driver", "{'capacity':300}");
     	sendPost("/driver", "{'capacity':350}");
     	sendPost("/driver", "{'capacity':400}");
     	sendPost("/driver", "{'capacity':450}");
     	sendPost("/driver", "{'capacity':500}");
     	sendPost("/driver", "{'capacity':550}");

     	// This shipment should also be offered to all drivers, but we limit the results to 10
     	// Order should be 10,11,12,5,6,7,8,9,2,4 (Since drivers 5-12 all have 0 offers, they're sorted
     	// lexicographically. That means that 10 comes before 5
     	JSONObject s4 = sendPost("/shipment", "{'capacity':5}");
     	assertEquals(10, s4.getJSONArray("offers").length());
     	assertEquals("10:4", s4.getJSONArray("offers").getJSONObject(0).getString("id"));
     	assertEquals("11:4", s4.getJSONArray("offers").getJSONObject(1).getString("id"));
     	assertEquals("12:4", s4.getJSONArray("offers").getJSONObject(2).getString("id"));
     	assertEquals("5:4", s4.getJSONArray("offers").getJSONObject(3).getString("id"));
     	assertEquals("6:4", s4.getJSONArray("offers").getJSONObject(4).getString("id"));
     	assertEquals("7:4", s4.getJSONArray("offers").getJSONObject(5).getString("id"));
     	assertEquals("8:4", s4.getJSONArray("offers").getJSONObject(6).getString("id"));
     	assertEquals("9:4", s4.getJSONArray("offers").getJSONObject(7).getString("id"));
     	assertEquals("2:4", s4.getJSONArray("offers").getJSONObject(8).getString("id"));
     	assertEquals("4:4", s4.getJSONArray("offers").getJSONObject(9).getString("id"));
    }

    @Test
    public void testRejectOffer() {
	sendPost("/driver", "{'capacity':150}");
	sendPost("/driver", "{'capacity':100}");
	// This shipment should be offered to driver 0 only
	sendPost("/shipment", "{'capacity':120}");

	// Driver 0 rejects shipment 0
	sendPut("/offer/0:0", "{'status': 'PASS'}");

	// Another shipment. Since Driver1 has 0 offers, and Driver0 got 1,
	// Driver1 should be first
	JSONObject s1 = sendPost("/shipment", "{'capacity':50}");
	assertEquals(2, s1.getJSONArray("offers").length());
	assertEquals("1:1", s1.getJSONArray("offers").getJSONObject(0).getString("id"));
	assertEquals("0:1", s1.getJSONArray("offers").getJSONObject(1).getString("id"));

	// Driver 1 accepts shipment 1
	sendPut("/offer/1:1", "{'status': 'ACCEPT'}");

	// Driver 1 still has only seen 1 offer, and driver 0 has seen 2
	JSONObject s2 = sendPost("/shipment", "{'capacity':50}");
	assertEquals(2, s2.getJSONArray("offers").length());
	assertEquals("1:2", s2.getJSONArray("offers").getJSONObject(0).getString("id"));
	assertEquals("0:2", s2.getJSONArray("offers").getJSONObject(1).getString("id"));	
    }

    @Test
    public void testRejectOffer2() throws Exception {
	sendPost("/driver", "{'capacity':50}");
	sendPost("/driver", "{'capacity':75}");
	sendPost("/driver", "{'capacity':100}");
	// This shipment should be offered to all drivers
	sendPost("/shipment", "{'capacity':50}");

	// Driver 0 rejects shipment 0
	sendPut("/offer/0:0", "{'status': 'PASS'}");
	// Driver 1 accepts shipment 0
	sendPut("/offer/1:0", "{'status': 'ACCEPT'}");
	// Driver 2 accepts shipment 0 (fails, because it's already been accepted by driver 1
	sendPut("/offer/2:0", "{'status': 'ACCEPT'}");

	JSONObject s1 = sendGet("/shipment/0");
	assertEquals("1:0", s1.getJSONArray("offers").getJSONObject(0).getString("id"));
	
	// This shipment should be offered to all drivers. They all should be equal, because
	// they all got an offer
	JSONObject s2 = sendPost("/shipment", "{'capacity':50}");
	assertEquals("0:1", s2.getJSONArray("offers").getJSONObject(0).getString("id"));
	assertEquals("1:1", s2.getJSONArray("offers").getJSONObject(1).getString("id"));
	assertEquals("2:1", s2.getJSONArray("offers").getJSONObject(2).getString("id"));
	
	// Driver 1 rejects twice (doesn't do anything more)
	sendPut("/offer/1:1", "{'status': 'PASS'}");
	sendPut("/offer/1:1", "{'status': 'PASS'}");

	// New shipment comes in. They all received 2 offers, so it's equal
	JSONObject s3 = sendPost("/shipment", "{'capacity':50}");
	assertEquals("0:2", s3.getJSONArray("offers").getJSONObject(0).getString("id"));
	assertEquals("1:2", s3.getJSONArray("offers").getJSONObject(1).getString("id"));
	assertEquals("2:2", s3.getJSONArray("offers").getJSONObject(2).getString("id"));
    }
    
    @Test
    public void testConcurrent() {
    	ExecutorService executor = Executors.newFixedThreadPool(10);
	List<WorkerThread> workers = new LinkedList<>();
	// Create a bunch of drivers and shipments at the same time. There shouldn't ever be a duplicate id.
	// A bunch of these will fail with concurrency errors
    	for ( int i = 0; i < 25; i++ ) {
    	    WorkerThread worker = new WorkerThread(new String[]{"POST", "/driver", "{'capacity':" + (i+1) + "}"});
    	    executor.execute(worker);
	    workers.add(worker);
    	}
	for ( int i = 25; i >= 0; i-- ) {
    	    WorkerThread worker = new WorkerThread(new String[]{"POST", "/shipment", "{'capacity':" + i + "}"});
    	    executor.execute(worker);
	    workers.add(worker);
	}
    	executor.shutdown();
    	while(!executor.isTerminated()) {
    	}

	// After we're all done, extract the ids from the successful operations. There shouldn't be any duplicates
	Set<String> s = new HashSet<>();
	for ( WorkerThread wt : workers ) {
	    if ( wt.getId() != null ) {
		if ( s.contains(wt.getId()) ) {
		    fail("Duplicate id: " + wt.getId());
		}
		s.add(wt.getId());
	    }
	}
    }

    @Test
    public void testConcurrentPut() throws Exception {
     	sendPost("/driver", "{'capacity':50}");
     	sendPost("/driver", "{'capacity':100}");
     	sendPost("/driver", "{'capacity':110}");
     	sendPost("/driver", "{'capacity':120}");
     	sendPost("/driver", "{'capacity':130}");
	
     	sendPost("/shipment", "{'capacity':50}");
	
	// Try to accept all 5 offers at the same time	
    	ExecutorService executor = Executors.newFixedThreadPool(5);
    	for ( int i = 0; i < 5; i++ ) {
    	    WorkerThread worker = new WorkerThread(new String[]{"PUT", "/offer/" + i + ":0", "{'status':'ACCEPT'}"});
    	    executor.execute(worker);
    	}
    	executor.shutdown();
    	while(!executor.isTerminated()) {
    	}

	// Look up the shipment. It should only have one accepted offer
	JSONObject s1 = sendGet("/shipment/0");
	assertEquals(1, s1.getJSONArray("offers").length());
	assertEquals(true, s1.getBoolean("accepted"));
	assertEquals("ACCEPTED", s1.getJSONArray("offers").getJSONObject(0).getString("status"));
	
	// Look up each driver. Only one should have an offer (that's accepted)
	JSONObject d0 = sendGet("/driver/0");
	JSONObject d1 = sendGet("/driver/1");
	JSONObject d2 = sendGet("/driver/2");
	JSONObject d3 = sendGet("/driver/3");
	JSONObject d4 = sendGet("/driver/4");
	assertEquals(1, d0.getJSONArray("offers").length() +
		     d1.getJSONArray("offers").length() +
		     d2.getJSONArray("offers").length() +
		     d3.getJSONArray("offers").length() +
		     d4.getJSONArray("offers").length());
    }

    public class WorkerThread implements Runnable {
    	private String[] cmds;
	private JSONObject result;
    	public WorkerThread(String[] cmds) {
    	    this.cmds = cmds;
	    this.result = null;
    	}
    	public void run() {
    	    try {
    		if ( cmds[0] == "GET" ) {
    		    result = sendGet(cmds[1]);
    		} else if ( cmds[0] == "POST" ) {
    		    result = sendPost(cmds[1], cmds[2]);
    		} else if ( cmds[0] == "PUT" ) {
    		    result = sendPut(cmds[1], cmds[2]);
    		}
    	    } catch( Exception e ) {
    	    }
    	}
	public String getId() {
	    // If there's a concurrency error, then there's no id
	    if ( result.has("error") ) {
		return null;
	    } else {
		return result.getString("id");
	    }
	}
    }
    
    private JSONObject sendGet(String url) throws Exception {
	URL obj = new URL(BASE_URL + url);
	HttpURLConnection con = (HttpURLConnection) obj.openConnection();

	// optional default is GET
	con.setRequestMethod("GET");

	int responseCode = con.getResponseCode();

	BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
	String inputLine;
	StringBuffer response = new StringBuffer();

	while ((inputLine = in.readLine()) != null) {
	    response.append(inputLine);
	}
	in.close();

	return new JSONObject(response.toString());
    }

    private JSONObject sendPut(String targetURL, String params) {
	return send("PUT", targetURL, params);
    }
    private JSONObject sendPost(String targetURL, String urlParameters) {
	return send("POST", targetURL, urlParameters);
    }
    
    private JSONObject send(String method, String targetURL, String urlParameters) {
	HttpURLConnection connection = null;

	try {
	    //Create connection
	    URL url = new URL(BASE_URL + targetURL);
	    connection = (HttpURLConnection) url.openConnection();
	    connection.setRequestMethod(method);
	    connection.setRequestProperty("Content-Length",
					  Integer.toString(urlParameters.getBytes().length));
	    connection.setRequestProperty("Content-Language", "en-US");

	    connection.setUseCaches(false);
	    connection.setDoOutput(true);

	    //Send request
	    DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
	    wr.writeBytes(urlParameters);
	    wr.close();

	    //Get Response
	    InputStream is = connection.getInputStream();
	    BufferedReader rd = new BufferedReader(new InputStreamReader(is));
	    StringBuilder response = new StringBuilder();
	    String line;
	    while ((line = rd.readLine()) != null) {
		response.append(line);
		response.append('\r');
	    }
	    rd.close();
	    return new JSONObject(response.toString());
	} catch (Exception e) {
	    e.printStackTrace();
	    return null;
	} finally {
	    if (connection != null) {
		connection.disconnect();
	    }
	}
    }
}
