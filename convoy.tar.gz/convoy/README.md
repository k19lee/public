INSTALLATION
------------

install maven
jdk8
redis3.2.8 (included)

> cd redis-3.2.8
> make
> ./src/redis-server&

mvn install -DskipTests

RUNNING
-------
mvn exec:java -Dexec.mainClass="Main"&

Now, you can either run the test suite, using

> mvn test

Or, you can use curl directly to hit the web server

> curl -X POST -d "{'capacity':5}" http://localhost:4567/driver
> curl -X GET http://localhost:4567/driver/0
